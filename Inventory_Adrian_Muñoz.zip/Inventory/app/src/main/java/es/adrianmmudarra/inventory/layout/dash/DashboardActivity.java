package es.adrianmmudarra.inventory.layout.dash;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import es.adrianmmudarra.inventory.R;

public class DashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
    }
}
